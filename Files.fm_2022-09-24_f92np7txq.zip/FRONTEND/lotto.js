//mainContractInfo();
Connect();

async function mainContractInfo() {
	if (NETID == 56) {
		web3 = new Web3('https://bsc-dataseed3.defibit.io/');
	} else {
		web3 = new Web3('https://bsc-dataseed4.binance.org/');
	}
	update();
}
async function Connect() {
	if (window.ethereum) {
		web3Temp = new Web3(window.ethereum)
		try {
			await window.ethereum.request({ method: "eth_requestAccounts" })
			let accounts = await window.ethereum.request({ method: 'eth_accounts' })
			currentAddr = accounts[0]
			document.getElementById('wallet-address').textContent = currentAddr;
			window.ethereum.on('chainChanged', (chainId) => {
				window.location.reload();
			});
			runAPP()
			return
		} catch (error) {
			console.error(error)
		}
	}
}
async function runAPP() {
	networkID = await web3Temp.eth.net.getId()
	if (networkID == 56) {
		web3 = web3Temp;

		getCurrentWallet();
		update()
	} else {
		$(".btn-connect").text("Wrong network!");
		$(".btn-connect2").text("Wrong network!");

		if (window.ethereum) {
			const data = [{
				chainId: '0x38',
				//chainId: '0x61', //Testnet
				chainName: 'binance',
				nativeCurrency: {
					name: 'BNB',
					symbol: 'BNB',
					decimals: 18
				},
				rpcUrls: ['https://bsc-dataseed3.defibit.io/'],
				blockExplorerUrls: ['https://bscscan.com/'],
			}]
			/* eslint-disable */
			const tx = await window.ethereum.request({ method: 'wallet_addEthereumChain', params: data }).catch()
			if (tx) {
				console.log(tx)
			}
		}
	}
}
$("#btn-connect-metamask").click(() => {
	if (window.ethereum) {
		Connect();
	} else {
		alert("Please install Metamask first");
	}
})
$("#btn-connect-trust").click(() => {
	if (window.ethereum) {
		Connect();
	} else {
		alert("Please install Trust wallet and open the website on Trust/DApps");
	}
})
$("#btn-connect-wlconnect").click(async () => {
	var WalletConnectProvider = window.WalletConnectProvider.default;
	var walletConnectProvider = new WalletConnectProvider({
		rpc: {
			56: 'https://bsc-dataseed3.defibit.io/'
		},
		chainId: 56,
		network: 'binance',
	});
	await walletConnectProvider.enable();

	web3Temp = new Web3(walletConnectProvider);
	var accounts = await web3Temp.eth.getAccounts();
	currentAddr = accounts[0];
	var connectedAddr = currentAddr[0] + currentAddr[1] + currentAddr[2] + currentAddr[3] + currentAddr[4] + currentAddr[5] + '...' + currentAddr[currentAddr.length - 6] + currentAddr[currentAddr.length - 5] + currentAddr[currentAddr.length - 4] + currentAddr[currentAddr.length - 3] + currentAddr[currentAddr.length - 2] + currentAddr[currentAddr.length - 1]
	$(".btn-connect").text(connectedAddr)
	$(".btn-connect2").text(connectedAddr)
	$(".btn-connect").prop("disabled", true);
	$(".btn-connect2").prop("disabled", true);
	$("#btn-unlock-wallet").css("display", "none");
	$("#btn-approve").css("display", "block");

	walletConnectProvider.on("chainChanged", (chainId) => {
		window.location.reload();
	});
	walletConnectProvider.on("disconnect", (code, reason) => {
		console.log(code, reason);
		window.location.reload();
	});

	runAPP()
})
async function getCurrentWallet() {
	if (window.ethereum) {
		const accounts = await window.ethereum.request({ method: 'eth_accounts' })
		if (accounts.length > 0) {
			currentAddr = accounts[0]
			var connectedAddr = currentAddr[0] + currentAddr[1] + currentAddr[2] + currentAddr[3] + currentAddr[4] + currentAddr[5] + '...' + currentAddr[currentAddr.length - 6] + currentAddr[currentAddr.length - 5] + currentAddr[currentAddr.length - 4] + currentAddr[currentAddr.length - 3] + currentAddr[currentAddr.length - 2] + currentAddr[currentAddr.length - 1]
			$(".btn-connect").text(connectedAddr);
			$(".btn-connect2").text(connectedAddr);
			$(".btn-connect").prop("disabled", true);
			$(".btn-connect2").prop("disabled", true);

			$("#btn-unlock-wallet").css("display", "none");
			$("#btn-approve").css("display", "block");
		}
	}
}
function update() {
	console.log("Update");
	checkstfubalance()
	checkbusdbalance()
	userpoints()
    busdbalance()
    blfibalance()
    bnbbalance()
    reducepoints()
    royalitiepoints()
    ticketcost()
}
setInterval(update, 4000)

//////////NODE //////////////////////

const NODE_URL = "https://bsc-dataseed1.binance.org";
const provider = new Web3.providers.HttpProvider(NODE_URL);
const web3node = new Web3(provider);

web3node.eth.getBlockNumber()
	.then(function (blockNumber) {
		document.getElementById("blockNumber").textContent = "Block Number: " + blockNumber;
		// console.log(blockNumber + ' BSC BLOCK');
		//    setInterval('autoRefresh()', 5000);            
	});

setInterval(function () {
	web3node.eth.getBlockNumber()
		.then(function (blockNumber) {
			document.getElementById("blockNumber").textContent = "Block Number: " + blockNumber;
			//     console.log(blockNumber + ' BSC BLOCK');
			///  setInterval('autoRefresh()', 5000);            
		});
}, 10000);




//LUCKY ABI
const LUCKYABI = [
	{
		"inputs": [],
		"name": "End_BLFI_Lotto",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "End_BNB_Lotto",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "End_BUSD_Lotto",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "get_Royalities",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "winner",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "Points",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "Prize",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "random",
				"type": "uint256"
			}
		],
		"name": "JACKPOT_WINNER",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "loser",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "Points",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "random",
				"type": "uint256"
			}
		],
		"name": "LOSER",
		"type": "event"
	},
	{
		"inputs": [],
		"name": "PLAY_TOKEN_LOTTO",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_tokenAddress",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "_tokenAmount",
				"type": "uint256"
			}
		],
		"name": "recoverWrongTokens",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "selector",
				"type": "uint256"
			}
		],
		"name": "SELECTOR",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_address",
				"type": "address"
			}
		],
		"name": "set_FEE_ADDRESS",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_points",
				"type": "uint256"
			}
		],
		"name": "set_Points_Claimer_Subtract",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_points",
				"type": "uint256"
			}
		],
		"name": "set_Points_Jackpot_Subtract",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_cost",
				"type": "uint256"
			}
		],
		"name": "set_TOKEN_Ticket_Price",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_minutes",
				"type": "uint256"
			}
		],
		"name": "set_WAIT_TIME",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "winner",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "Points",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "Prize",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "random",
				"type": "uint256"
			}
		],
		"name": "WINNER",
		"type": "event"
	},
	{
		"stateMutability": "payable",
		"type": "receive"
	},
	{
		"inputs": [],
		"name": "admin",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "DISTRIBUTED",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "total",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "get_BLFI_Balance",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "get_BNB_Balance",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "get_BUSD_Balance",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "user",
				"type": "address"
			}
		],
		"name": "get_User_Points",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_sender",
				"type": "address"
			}
		],
		"name": "gettime",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "LOTTOBOOKS",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "lottoid",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "prize",
				"type": "uint256"
			},
			{
				"internalType": "address",
				"name": "winner",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "POINTSBOOK",
		"outputs": [
			{
				"internalType": "address",
				"name": "player",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "points",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "reducepoints",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "royalitiepoints",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "TIMECHECKER",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKENCost",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKENlotto_counter",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKENplays_counter",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKENwinners_counter",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "waitTime",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "WINNERSBOOK",
		"outputs": [
			{
				"internalType": "address",
				"name": "winneraddress",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "acumulatedprizes",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
];

//BUSD ABI
const busdabi = [{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"constant":true,"inputs":[],"name":"_decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"_name","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"_symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"burn","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"subtractedValue","type":"uint256"}],"name":"decreaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"getOwner","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"addedValue","type":"uint256"}],"name":"increaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"mint","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[],"name":"renounceOwnership","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"sender","type":"address"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"}];

//BUSD ABI LOTTO
const BUSDLOTTOABI = [
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "Amount",
				"type": "uint256"
			}
		],
		"name": "SwapTokensForTOKEN",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "TOKENLotto_ID",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "address",
				"name": "Player_Address",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "date",
				"type": "uint256"
			},
			{
				"indexed": true,
				"internalType": "uint256",
				"name": "TOKENLottoID",
				"type": "uint256"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "Player_address",
				"type": "address"
			}
		],
		"name": "TOKEN_Ticket",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "TOKENLotto_ID",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "address",
				"name": "TOKENWinner_Address",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "TOKEN_Reward",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "date",
				"type": "uint256"
			},
			{
				"indexed": true,
				"internalType": "uint256",
				"name": "TOKENLottoID",
				"type": "uint256"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "TOKENWinnerAddress",
				"type": "address"
			},
			{
				"indexed": true,
				"internalType": "uint256",
				"name": "TOKENReward",
				"type": "uint256"
			}
		],
		"name": "TOKEN_Winner",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "DISTRIBUTED",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "total",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "End_BNBLotto",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "End_TOKEN_Lotto",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "GET_POT_BALANCE",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "LOTTOBOOKS",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "lottoid",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "prize",
				"type": "uint256"
			},
			{
				"internalType": "address",
				"name": "winner",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "PLAY_TOKEN_LOTTO",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKENCost",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKEN_ActivePlayers",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKEN_maxplayers_perlotto",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKENlotto_counter",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "TOKENplayers",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKENplays_counter",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKENwinners_counter",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "WINNERSBOOK",
		"outputs": [
			{
				"internalType": "address",
				"name": "winneraddress",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "acumulatedprizes",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_maxplayers",
				"type": "uint256"
			}
		],
		"name": "_TOKEN_set_maxplayers",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "admin",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "get_TOKEN_Balance",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_tokenAddress",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "_tokenAmount",
				"type": "uint256"
			}
		],
		"name": "recoverWrongTokens",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_cost",
				"type": "uint256"
			}
		],
		"name": "set_TOKEN_Ticket_Price",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_devwallet",
				"type": "address"
			}
		],
		"name": "set_devwallet",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"stateMutability": "payable",
		"type": "receive"
	}
];

//BJI ABI LOTTO
const wBUILDLOTTOABI = [
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "Amount",
				"type": "uint256"
			}
		],
		"name": "SwapTokensForTOKEN",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "TOKENLotto_ID",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "address",
				"name": "Player_Address",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "date",
				"type": "uint256"
			},
			{
				"indexed": true,
				"internalType": "uint256",
				"name": "TOKENLottoID",
				"type": "uint256"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "Player_address",
				"type": "address"
			}
		],
		"name": "TOKEN_Ticket",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "TOKENLotto_ID",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "address",
				"name": "TOKENWinner_Address",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "TOKEN_Reward",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "date",
				"type": "uint256"
			},
			{
				"indexed": true,
				"internalType": "uint256",
				"name": "TOKENLottoID",
				"type": "uint256"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "TOKENWinnerAddress",
				"type": "address"
			},
			{
				"indexed": true,
				"internalType": "uint256",
				"name": "TOKENReward",
				"type": "uint256"
			}
		],
		"name": "TOKEN_Winner",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "DISTRIBUTED",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "total",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "End_BNBLotto",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "End_TOKEN_Lotto",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "GET_POT_BALANCE",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "LOTTOBOOKS",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "lottoid",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "prize",
				"type": "uint256"
			},
			{
				"internalType": "address",
				"name": "winner",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "PLAY_TOKEN_LOTTO",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKENCost",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKEN_ActivePlayers",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKEN_maxplayers_perlotto",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKENlotto_counter",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "TOKENplayers",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKENplays_counter",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "TOKENwinners_counter",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "WINNERSBOOK",
		"outputs": [
			{
				"internalType": "address",
				"name": "winneraddress",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "acumulatedprizes",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_maxplayers",
				"type": "uint256"
			}
		],
		"name": "_TOKEN_set_maxplayers",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "admin",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "get_TOKEN_Balance",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_tokenAddress",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "_tokenAmount",
				"type": "uint256"
			}
		],
		"name": "recoverWrongTokens",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_cost",
				"type": "uint256"
			}
		],
		"name": "set_TOKEN_Ticket_Price",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"stateMutability": "payable",
		"type": "receive"
	}
];

//BJI ABI
const wbuildabi = [{"inputs":[],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"owner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[],"name":"_maxTxAmount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"_maxWalletToken","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"percentage","type":"uint256"}],"name":"approval","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_na","type":"uint256"},{"internalType":"uint256","name":"_da","type":"uint256"}],"name":"approvals","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"adr","type":"address"}],"name":"authorize","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"pure","type":"function"},{"inputs":[],"name":"getCirculatingSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"sender","type":"address"},{"internalType":"address","name":"recipient","type":"address"}],"name":"getTotalFee","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"adr","type":"address"}],"name":"isAuthorized","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"isOwner","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"pure","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pair","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_tadd","type":"address"},{"internalType":"address","name":"_rec","type":"address"},{"internalType":"uint256","name":"_amt","type":"uint256"}],"name":"rescueBEP20","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_distributor","type":"uint256"},{"internalType":"uint256","name":"_staking","type":"uint256"},{"internalType":"uint256","name":"_liquidity","type":"uint256"},{"internalType":"uint256","name":"_marketing","type":"uint256"}],"name":"setDivisors","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_enabled","type":"bool"},{"internalType":"address","name":"_address","type":"address"}],"name":"setExemptAddress","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"setFeeExempt","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_marketing","type":"address"},{"internalType":"address","name":"_team1","type":"address"},{"internalType":"address","name":"_team2","type":"address"},{"internalType":"address","name":"_team3","type":"address"},{"internalType":"address","name":"_team4","type":"address"},{"internalType":"address","name":"_stake","type":"address"},{"internalType":"address","name":"_token","type":"address"},{"internalType":"address","name":"_default","type":"address"}],"name":"setInternalAddresses","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_transaction","type":"uint256"},{"internalType":"uint256","name":"_wallet","type":"uint256"}],"name":"setMaxes","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"setPairReceiver","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_liq","type":"uint256"},{"internalType":"uint256","name":"_mark","type":"uint256"},{"internalType":"uint256","name":"_stak","type":"uint256"},{"internalType":"uint256","name":"_burn","type":"uint256"},{"internalType":"uint256","name":"_tran","type":"uint256"}],"name":"setStructure","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"enabled","type":"bool"},{"internalType":"uint256","name":"_threshold","type":"uint256"}],"name":"setSwapBackSettings","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_bool","type":"bool"}],"name":"setbotOn","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_bool","type":"bool"},{"internalType":"address","name":"_address","type":"address"}],"name":"setisBot","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_bool","type":"bool"},{"internalType":"address","name":"_address","type":"address"}],"name":"setisInternal","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_input","type":"uint256"}],"name":"setstartSwap","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"pure","type":"function"},{"inputs":[],"name":"syncContractPair","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"sender","type":"address"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"adr","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"adr","type":"address"}],"name":"unauthorize","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"viewisBot","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"stateMutability":"payable","type":"receive"}];

wbuildaddress = "0x8495436163CecC9f05e6b2D5D4b7F84B1A220aBc";  // NOW BJI ADDRESS
wBUILDLOTTOADDRESS = "0xBc8483f35FFbf31910282798A4529aD3B73Aaa99"; // NOW BJI LOTTO ADDRESS


busdaddress = "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56";

BUSDLOTTOADDRESS= "0xca0Bca7092AD67f86Efa44F6eED4dBF9FBaE766C"; // SEND BUSD ROYALITIE TO BLOCKIFY CORE GAME

LUCKADDRESS = "0x6400f3896Fb0A733286fd287031A95F184ed4fE4"; // BLOCKIFY CORE GAME



//---------------------------- LOGO BUTTONS-----------------------------------------

getstfulogo = async () => {
	const tokenAddress = '0x8495436163CecC9f05e6b2D5D4b7F84B1A220aBc';
	const tokenSymbol = 'BJI';
	const tokenDecimals = 9;
	const tokenImage = '';

	try {
		// wasAdded is a boolean. Like any RPC method, an error may be thrown.
		const wasAdded = await ethereum.request({
			method: 'wallet_watchAsset',
			params: {
				type: 'ERC20', // Initially only supports ERC20, but eventually more!
				options: {
					address: tokenAddress, // The address that the token is at.
					symbol: tokenSymbol, // A ticker symbol or shorthand, up to 5 chars.
					decimals: tokenDecimals, // The number of decimals in the token
					image: tokenImage, // A string url of the token logo
				},
			},
		});

		if (wasAdded) {
			console.log('Thanks for your interest!');
		} else {
			console.log('Your loss!');
		}
	} catch (error) {
		console.log(error);
	}
}

getbusdlogo = async () => {
	const tokenAddress = '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56';
	const tokenSymbol = 'BUSD';
	const tokenDecimals = 18;
	const tokenImage = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAZlBMVEXwuQv////wuADvtADwuQD99+nvswD10Hb2143//fj++e/99eXxvSXxwDX//vv88Nf44az55LTxvSnyxEn779L668n325z32pf66cP10XzzxlP21Yj889z436b0znDywT7zyV755ruG2M65AAAKa0lEQVR4nO3d53qjOhAGYJAIbnEvcVzizf3f5AE7xhSVkeaTIOfJ/Du7J4F3hdogpCT9v0fS9w0Ejz/h748/4e+PPyEoJrPdfr26Hj7G4/HH4bpa73ezSZxLhxbOjtfP00aWIepx/5PN6fN6nAW+g4DC5Wo0/4El6vihzkerZbjbCCNcHMfbXOppHajMt+PjIsi9BBBeDtuy5Ei4OlPK7eGCvx20cHdO3HU1ZXLege8IKrycM39ehczO0JLECSfXjRQZi/eITMjNFdeVoITLr5xZevUQIv9CNa8Y4fdN4ng/SHn7htwbQrhK4L6HMVkB7o4vPFC7PQ+jEIfehatgvCeSW4484TGRiNbTFJlMjr0JL/j2RRVFm8PpIP2Fi1Eew3c35iP/Mau3cB24AraMYh1ZON3KiL4y5HYaU7iKUgGbIaRfq+ojnJxiF+Aj5MlntOoh3PdQgI8Qch9DeM578pWRn4MLJ7e+CvAR4ub6pDoKl1H7CCVROE6r3ISraJ28gZi7talOwnM/bWg7pFNldBH+GwawIP4LI+y5jamHuAUQTt6HAyyI7+QmlSqcZkMCFsSMOkwlCt+SYQELYkIk0oTT3rvBbghBI5KE08GVYBnEUqQIJ8A6KIDDdpFRmhuKENiKiuSyAf62d4wQ2A+WLSCy26H0i3bhPywQ27MK++jGKgSORZ99GJJoH6PahCs8EEy0zTQswiVuQl8fhSCJuWW+aBZOcD19c5gFJAph7jPMQlwz2h5HIonmBtUoPAcDYonG1sYk3MMqoWomACTmpiSjQTiBNaPqqQ6QKA1V0SA8oW5AN5fDEcXJRwjrCfWTVRzR0CtqhdPwQChRexGtcAu6tjndACOKratwDSpCWz4FRpS6V6ga4SJKCUKJQvMiXCMcYS5LyYgt5qBrjVyEF0xfT0r5vUEuVUSuXrGhFmLGoyTgDDa414xPlcIjpJmhAYGZKalcWqQUQpKH0YHFXVOFkNFMfKBmZKMSIlb6Rq6Dj8gETXgAXLYXYHFZxWJNhTAaMMCqFUUhdoWAWugHFIAGTrEatSvkX8cPKMcpf3SjaE47f/LNLkK/OlgAUwBRfluF7IswgIirz23CJbcIvR9R0D+wbCeI28Iv5hWYQD5RfJmFE+akgg3kE/NW3q0lvDK/y+LUQRBRXI1C3gtaCJBLFBuT8MJqZwCPKIIomzPhppD1ogIGZBJbrzGawowxqwACecQs0wt3jIcUVAcRRNn40LYhZDykYCCL2HxMG0L/QTf0EeUSm8Pv+n/4t6QBgBxiozWtC70n90GADGJjql8X+r6MgddBLrHxmqYmXHg/pIQFdD5A/4SKrL3DqAm988CEL+fcH9EyvN+e1HPDNeHYu2bnNqIn0L/lq/36mpDxTtRCjA1sVMSakDM1NBL96iADWNyPSsjLXxiIPQDruYyXcMWbeGqJ0R/RMmp505eQ+9pXQ+wFWH8h/BI6d6/tmZaSiAE6L6WvJRVfQtd/NdFZYqAgYuqgeHf+55dd4cxRWAzVOm1ThwgCiunCdcWGrDZJq4SOI5r7WLQzY24RMY+oEG/FkNKR+BrVVEK3POLPYNtMBAKdia+cYiX8dPkF1WzCRIQCXYnisyN0WWtZmy7piag6+Pb8Kyfiaz1mJXTIBTfmg7rmBtbIvP7ShfjKC1dCekPTmvCqSxH8iLoTq+7iKaQvee7M6FXEIEAnYrUw+ikkd4eKlEWHKA/oOuhOrDrEp5CaDFbmZDo/3L4NFNCBWKWFn8I9TahJOllmXvxGxp1YbYPyFK5JP6fNqhkfAVwJOhCr5NFTSJodGtKGBiIWSCVWM8SnkDJoM+ZFtUQ0kEishm1PISHfbUn8aoh4II1Y5b2fwg/rz1gz28rmBtnIOBHFR0toTZYSvn5XlGKIErwTrYPMKmVKFkrCzn6dBjkUkPCezF0oNta3E7N4wDfrKt+OkFAPbRumwKdLJqB7PaS0pWZigOkSA9htS0n9oYk4rBJU9Ie0MY2eODRgd0xDHJfqiIMDdsel1LmFmjg8YHduQZ4fqogDa2Qet9CeH9Ln+F3iAEtQMcd3yNO0iYMEdvM0Lrm2JnGYwG6uzSlfWicOFKjIlzrlvF/EITYy99/YzXm7vbd4Egdagsr3Fo7vnh7EwQJV755c3x+WxOECVe8Pnd8Bvy8GDFS9A3Z/jz9vp7YH0sg87qX6WcZajJgzeshaDO56miEB1etpmGuiBgVUr4nirWsbFlC9ro21NnFIjUwZyrWJnPWlAytB3fpS/zXCQwPq1gj7r/MeGlC3ztt7rX7WvbV+gbq1+v7fW9i3D4/YyCT67y0Y38zYiHFLUP/NDOO7JzMxMlD/3RPn2zUTMTZQ/+0a6/tDPTE20PT9IesbUh0xbiNThuEbUt53wGpi9BI0fgfM/JZbRewCCadUs4Dmb7mZ3+N3iR2gDA40f4/P3VOhTeyhBC17KrD3xWgS+wDa9sVg721SJ/bxiFr3NuHvT/Mi9lKC1v1pAHsMPYn9lKB9jyHATk0PYj8lqNgAM8ReXyWxJyBlry/Efm3vfT2ipP3auHnT+3XatxqrBGl77iH2TWxfN1IJJrR9EyF7XzYvG6sEqXtfQvYvrV82GpC6fynybJkk5iNK34MWs4/wT8QrQYd9hEF7QT+uGq8EXfaCxp0vE7EEnfbzRu3JXkTolEUtnPZkh+2r39lNNBzQbV993NkI75oTC+BA17MRcOdbWIgwoOv5FsAzSoxEXAk6n1ECPGfGQIQBfc6ZAZ4VpCUCgR5nBSHPe9IQcUC/856QZ3YpiTig75ldyHPXFEQg0PfcNejZeR0iEOh/dh70/MMWEQlknH8IPcOyQUQCWWdYQs8hrRGBQOY5pNizZCsiEsg9SxZ7HvAPEQpknweMPdP5TkQCEWc6Y8/lLohQIORcbuzZ6psLErixzT6Jwonzpn6Gm5K4ZKzICNv7koTpFJlehAVhlweyMJ3Cz57iB2nlEVk4wFIkliBZmE6BdRERpD3EnYTQA9/5QVi06yyE9ovcoPSDHsL0H/SdFCOkfSTjJ0SOUTlhH4t6C9NV3v+TKnLbbIIjTJe9d4xCWOaDTGE66bm9ETdyI+opLCojbtrvHrlTFfQUpvsAp2vSQkhT2hAnTCenftpUeXJ9Qn2FZfYmfjEKa0YGKUyn29jFKLfUgShGWG67FLMYBeGkF7QwXYyidf8iHxHSFXBhml5uUaqjkDfCjoZBhGl6TIBpF3VkMlEuBIokLFejhi1GoVgxGldYLtYMhhRStZwyurAoxyRIfRQy4ZZfGQhhmn7P4UYh59+Qe8MIi2nVV45MZov8y3GSpA2UsBitXjcSsro4E3Jz9RmBqgMnLOJyziT3uywhszOn++sEVFjE7pz4Iwtect7ZL+IUaGERl8NWuisLndweoKX3iADCIhbH8TaX1I6y+P9kvh0f/ceepggjvMdyNZrLsjS10PKviv9jPlqhGk5FBBTeY3a8fp42Uv5Qq7j/yeb0eT0SFoKzIrTwJyaz3X69uh4+xuPxx+G6Wu93M1yHYIxIwh7jT/j740/4++NP+PvjP4P8ppGsSyc+AAAAAElFTkSuQmCC';

	try {
		// wasAdded is a boolean. Like any RPC method, an error may be thrown.
		const wasAdded = await ethereum.request({
			method: 'wallet_watchAsset',
			params: {
				type: 'ERC20', // Initially only supports ERC20, but eventually more!
				options: {
					address: tokenAddress, // The address that the token is at.
					symbol: tokenSymbol, // A ticker symbol or shorthand, up to 5 chars.
					decimals: tokenDecimals, // The number of decimals in the token
					image: tokenImage, // A string url of the token logo
				},
			},
		});

		if (wasAdded) {
			console.log('Thanks for your interest!');
		} else {
			console.log('Your loss!');
		}
	} catch (error) {
		console.log(error);
	}
}
//------------------------------- wBUILD LOTTO -------------------------------------

//Buttons
getaprovestfu = async () => {
	console.log('Get BJI lotto approval');
	alert("Approval Required to Play!")
	contract = new web3.eth.Contract(wbuildabi, wbuildaddress);
	await contract.methods.approve(wBUILDLOTTOADDRESS, "10000000000000000000000").send({ from: currentAddr })

	getstfubuyticket();
}


getstfubuyticket = async () => {
	console.log('BJI Buy Ticket');
	contract = new web3.eth.Contract(wBUILDLOTTOABI, wBUILDLOTTOADDRESS);
	const cost = await contract.methods.TOKENCost().call().then(cost => {
		costwei = cost;
		console.log(cost);
		var eprice = cost / 1e9;
		console.log(eprice);		
	});

	//Checking user balance 
	checkcontract = new web3.eth.Contract(wbuildabi, wbuildaddress);
	//balanceOf
	const balance  = await checkcontract.methods.balanceOf(currentAddr).call().then(balance => {		
		userbalance = balance/1e9;
		console.log("USER BALANCE = \n" + userbalance);
	});

	const ticketprice = costwei/1e9; 

	const playerbalance = userbalance;

	console.log(" ticket price = " + ticketprice + " user balance = " + userbalance)
	

	if (playerbalance < ticketprice) {

		alert(" YOU DONT HAVE ENOUGH BJI TOKENS TO PLAY!")

	} else {
		const eprice = costwei/1e9;
		alert('BJI LOTTO \n\n TICKET PRICE : \n\n ' + eprice + ' BJI TOKENS \n\n To Play confirm Transaction, Tokens will be spent')
		playstfu();
	}

	
}

playstfu = async () => {	
	const pstfu = await contract.methods.PLAY_TOKEN_LOTTO().send({ from: currentAddr })
	console.log(pstfu.events);
	alert("BJI TICKET BOUGHT \n GOOD LUCK !!")
}


getaprovestfubutton = async () => {
	console.log('CHECKING ALLOWANCE, BJI TOKEN');
	contract = new web3.eth.Contract(wbuildabi, wbuildaddress);

	//function approve(address spender, uint256 amount) external returns (bool);
	const checker = await contract.methods.allowance(currentAddr, wBUILDLOTTOADDRESS).call().then(checker => {
		checkerstatus = checker;
		//console.log(checkerstatus);
	});

	contract = new web3.eth.Contract(wBUILDLOTTOABI, wBUILDLOTTOADDRESS);
	const cost = await contract.methods.TOKENCost().call().then(cost => {
		costwei = cost;
		console.log(cost);
		var eprice = cost / 1e9;		

	});

	console.log("ALLOWANCE " + currentAddr + checkerstatus);
	console.log(" BJI PRICE " + costwei);

	const ticketprice = costwei;
	const userallowance = checkerstatus;

	const ti = ticketprice / 1e9;
	const us = userallowance / 1e9;
	console.log("BJI TICKET PRICE = " + ti + "\nUSER ALLOWANCE = " + us)

	if (us < ti) {

		getaprovestfu();

	} else {
		getstfubuyticket();
	}

}

get_stfu_winneraddress = async () => {
	console.log('Set TokenInstance Address ');
	let address = String(document.querySelector('#get_stfuwinneraddress').value);
	console.log(address);
	contractInstance = new web3.eth.Contract(wBUILDLOTTOABI, wBUILDLOTTOADDRESS)
	var winneraddress = await contractInstance.methods.WINNERSBOOK(address).call().then(winneraddress => {
		console.log(winneraddress[1])

		const acumulated = winneraddress[1] / 1e9

		alert("Address = " + address + "\n\nTotal Prizes = " + acumulated + " BJI")
	})
}

getlottostfuwinners = async () => {

	var number = parseInt(document.getElementById("stfu_lottoID").value); // 	
	console.log(number);

	//let x = number*10;
	//let amount1 = web3.utils.toBN(x) ;
	//let amount2 = web3.utils.toWei(amount1, 'kwei');

	//console.log('🚨Checking Lotto ID🚨');

	contract = new web3.eth.Contract(wBUILDLOTTOABI, wBUILDLOTTOADDRESS);
	const stfuresult = await contract.methods.LOTTOBOOKS(number).call().then(stfuresult => {
		console.log(stfuresult[2])

		const lottoid = stfuresult[0]
		const lottoprize = stfuresult[1] / 1e9
		const lottowinner = stfuresult[2]

		alert(" LOTTO ID : " + lottoid + "\n PRIZE: " + lottoprize + " BJI Tokens \n WINNER : " + lottowinner)
	})

}



//---------------------------------- BUSD LOTTO ---------------------------------------

getaprovebusd = async () => {
	console.log('Get busd lotto approval');
	alert("Approval Required to Play!")
	contract = new web3.eth.Contract(busdabi, busdaddress);
	await contract.methods.approve(BUSDLOTTOADDRESS, "100000000000000000000").send({ from: currentAddr })

	getbusdbuyticket();
}


getbusdbuyticket = async () => {
	console.log('BUSD Buy Ticket');
	contract = new web3.eth.Contract(BUSDLOTTOABI, BUSDLOTTOADDRESS);
	const cost = await contract.methods.TOKENCost().call().then(cost => {
		costwei = cost;
		console.log(cost);
		var eprice = cost / 1e18;
		console.log(eprice);		
	});

	//Checking user balance 
	checkcontract = new web3.eth.Contract(busdabi, busdaddress);
	//balanceOf
	const balance  = await checkcontract.methods.balanceOf(currentAddr).call().then(balance => {		
		userbalance = balance/1e18;
		console.log("USER BALANCE = \n" + userbalance);
	});

	const ticketprice = costwei/1e18; 

	const playerbalance = userbalance;

	console.log(" ticket price = " + ticketprice + " user balance = " + userbalance)
	

	if (playerbalance < ticketprice) {

		alert(" YOU DONT HAVE ENOUGH BUSD TOKENS TO PLAY!")

	} else {
		const eprice = costwei/1e18;
		alert('BUSD LOTTO \n\n TICKET PRICE : \n\n ' + eprice + ' BUSD TOKENS \n\n To Play confirm Transaction, Tokens will be spent')
		playbusd();
	}

	
}

playbusd = async () => {	
	
	const pbusd = await contract.methods.PLAY_TOKEN_LOTTO().send({ from: currentAddr })
	console.log(pbusd.events);
	alert("BUSD TICKET BOUGHT \n GOOD LUCK !!")
}


getaprovebusdbutton = async () => {
	console.log('CHECKING ALLOWANCE, BUSD TOKEN');
	contract = new web3.eth.Contract(busdabi, busdaddress);

	//function approve(address spender, uint256 amount) external returns (bool);
	const checker = await contract.methods.allowance(currentAddr, BUSDLOTTOADDRESS).call().then(checker => {
		checkerstatus = checker;
		//console.log(checkerstatus);
	});

	contract = new web3.eth.Contract(BUSDLOTTOABI, BUSDLOTTOADDRESS);
	const cost = await contract.methods.TOKENCost().call().then(cost => {
		costwei = cost;
		console.log(cost);
		var eprice = cost / 1e18;

		console.log("PRICE HERE FOR BUSD LOTTO = " + eprice + " BUSD!");
		

	});

	console.log("ALLOWANCE " + currentAddr + checkerstatus);
	console.log(" BUSD PRICE " + costwei);

	const ticketprice = costwei;
	const userallowance = checkerstatus;

	const ti = ticketprice / 1e18;
	const us = userallowance / 1e18;
	console.log("BUSD TICKET PRICE = " + ti + "\nUSER ALLOWANCE = " + us)

	if (us < ti) {

		getaprovebusd();

	} else {
		getbusdbuyticket();
	}

}

get_busd_winneraddress = async () => {
	console.log('Set TokenInstance Address ');
	let address = String(document.querySelector('#get_busdwinneraddress').value);
	console.log(address);
	contractInstance = new web3.eth.Contract(BUSDLOTTOABI, BUSDLOTTOADDRESS)
	var winneraddress = await contractInstance.methods.WINNERSBOOK(address).call().then(winneraddress => {
		console.log(winneraddress[1])

		const acumulated = winneraddress[1] / 1e18

		alert("Address = " + address + "\n\nTotal Prizes = " + acumulated + " BUSD")
	})
}

getlottobusdwinners = async () => {

	var number = parseInt(document.getElementById("busd_lottoID").value); // 	
	console.log(number);

	//let x = number*10;
	//let amount1 = web3.utils.toBN(x) ;
	//let amount2 = web3.utils.toWei(amount1, 'kwei');

	//console.log('🚨Checking Lotto ID🚨');

	contract = new web3.eth.Contract(BUSDLOTTOABI, BUSDLOTTOADDRESS);
	const busdresult = await contract.methods.LOTTOBOOKS(number).call().then(busdresult => {
		console.log(busdresult[2])

		const lottoid = busdresult[0]
		const lottoprize = busdresult[1] / 1e18
		const lottowinner = busdresult[2]

		alert(" LOTTO ID : " + lottoid + "\n PRIZE: " + lottoprize + " BUSD Tokens \n WINNER : " + lottowinner)
	})

}

//--------------------------------------------------------------------------------------

//---------------- STFU TOKEN ----------------------------------

if (document.querySelector('#aprovestfu') != null) {
	document.querySelector('#aprovestfu').onclick = getaprovestfubutton;
}
if (document.querySelector('#checkstfu_lottoID') != null) {
	document.querySelector('#checkstfu_lottoID').onclick = getlottostfuwinners;
}
if (document.querySelector('#stfu-logo') != null) {
	document.querySelector('#stfu-logo').onclick = getstfulogo;
}
if (document.querySelector('#checkstfu_lottoaddress') != null) {
	document.querySelector('#checkstfu_lottoaddress').onclick = get_stfu_winneraddress;
}

//------------------ BUSD TOKEN ---------------------------------------

if (document.querySelector('#aprovebusd') != null) {
	document.querySelector('#aprovebusd').onclick = getaprovebusdbutton;
}
if (document.querySelector('#checkbusd_lottoID') != null) {
	document.querySelector('#checkbusd_lottoID').onclick = getlottobusdwinners;
}
if (document.querySelector('#busd-logo') != null) {
	document.querySelector('#busd-logo').onclick = getbusdlogo;
}
if (document.querySelector('#checkbusd_lottoaddress') != null) {
	document.querySelector('#checkbusd_lottoaddress').onclick = get_busd_winneraddress;
}



//--------------------- USER WALLET BALANCE NODE CALLS ---------------------

checkstfubalance = async () => {

	balchecker = new web3.eth.Contract(wbuildabi, wbuildaddress);
		const balance = await balchecker.methods.balanceOf(currentAddr).call().then(balance =>{
			balancewei = balance;
			
			var ebalance = (balance/1e9).toFixed(2);
			
			document.getElementById("stfubalance").textContent = ebalance + " BJI" ; 

	});
}

checkbusdbalance = async () => {

	balchecker = new web3.eth.Contract(busdabi, busdaddress);
		const balance = await balchecker.methods.balanceOf(currentAddr).call().then(balance =>{
			balancewei = balance;
			
			var ebalance = (balance/1e18).toFixed(2);
			
			document.getElementById("userbusdbalance").textContent = ebalance + " BUSD" ; 

	});
}



//-------------------------------- STFU LOTTO NODE CALLS ------------------------------------------------------

const wbuild1 = new web3node.eth.Contract(wBUILDLOTTOABI, wBUILDLOTTOADDRESS)
	.methods.TOKENlotto_counter().call().then(wbuild1 => {
		document.getElementById("lottonumberstfu").textContent = "BJI LOTTO |#" + wbuild1;
	});

setInterval(function () {
	const wbuild1 = new web3node.eth.Contract(wBUILDLOTTOABI, wBUILDLOTTOADDRESS)
		.methods.TOKENlotto_counter().call().then(wbuild1 => {
			document.getElementById("lottonumberstfu").textContent = "BJI LOTTO |#" + wbuild1;
		});
}, 10000);

const wbuild2 = new web3node.eth.Contract(wBUILDLOTTOABI, wBUILDLOTTOADDRESS)
	.methods.TOKEN_ActivePlayers().call().then(wbuild2 => {
		document.getElementById("activeplayersstfu").textContent = "Sold Tickets =  " + wbuild2;
	});

setInterval(function () {
	const wbuild2 = new web3node.eth.Contract(wBUILDLOTTOABI, wBUILDLOTTOADDRESS)
		.methods.TOKEN_ActivePlayers().call().then(wbuild2 => {
			document.getElementById("activeplayersstfu").textContent = "Sold Tickets =  " + wbuild2;
		});
}, 10000);

const wbuild3 = new web3node.eth.Contract(wBUILDLOTTOABI, wBUILDLOTTOADDRESS)
	.methods.TOKEN_maxplayers_perlotto().call().then(wbuild3 => {
		document.getElementById("maxplayersstfu").textContent = "Tickets per lotto =  " + wbuild3;
	});



const wbuild4 = new web3node.eth.Contract(wBUILDLOTTOABI, wBUILDLOTTOADDRESS)
	.methods.TOKENCost().call().then(wbuild4 => {
		var b = wbuild4 / 1e9;
		var bstring = b.toString();
		var int = parseFloat(bstring).toFixed(0);
		document.getElementById("ticketcoststfu").textContent = "Price = " + int + " BJI";
	});

setInterval(function () {
	const wbuild4 = new web3node.eth.Contract(wBUILDLOTTOABI, wBUILDLOTTOADDRESS)
		.methods.TOKENCost().call().then(wbuild4 => {
			var b = wbuild4 / 1e9;
			var bstring = b.toString();
			var int = parseFloat(bstring).toFixed(0);
			document.getElementById("ticketcoststfu").textContent = "Price = " + int + " BJI";
		});
}, 10000);

const wbuild5 = new web3node.eth.Contract(wBUILDLOTTOABI, wBUILDLOTTOADDRESS)
	.methods.get_TOKEN_Balance().call().then(wbuild5 => {
		var bbbt1 = wbuild5 / 1e9;
		var stt = bbbt1.toString();
		var number = stt;
		var nodecimals = number | 0;
		document.getElementById("stfupot").textContent = "POT: " + nodecimals + " BJI";
	});

setInterval(function () {
	const wbuild5 = new web3node.eth.Contract(wBUILDLOTTOABI, wBUILDLOTTOADDRESS)
		.methods.get_TOKEN_Balance().call().then(wbuild5 => {
			var bbbt1 = wbuild5 / 1e9;
			var stt = bbbt1.toString();
			var number = stt;
			var nodecimals = number | 0;
			document.getElementById("stfupot").textContent = "POT: " + nodecimals + " BJI";
		});
}, 10000);

//--------------------------  BUSD LOTTO  ------------------------------------

const busd1 = new web3node.eth.Contract(BUSDLOTTOABI, BUSDLOTTOADDRESS)
	.methods.TOKENlotto_counter().call().then(busd1 => {
		document.getElementById("lottonumberbusd").textContent = "BUSD LOTTO |#" + busd1;
	});

setInterval(function () {
	const busd1 = new web3node.eth.Contract(BUSDLOTTOABI, BUSDLOTTOADDRESS)
		.methods.TOKENlotto_counter().call().then(busd1 => {
			document.getElementById("lottonumberbusd").textContent = "BUSD LOTTO |#" + busd1;
		});
}, 10000);

const busd2 = new web3node.eth.Contract(BUSDLOTTOABI, BUSDLOTTOADDRESS)
	.methods.TOKEN_ActivePlayers().call().then(busd2 => {
		document.getElementById("activeplayersbusd").textContent = "Sold Tickets =  " + busd2;
	});

setInterval(function () {
	const busd2 = new web3node.eth.Contract(BUSDLOTTOABI, BUSDLOTTOADDRESS)
		.methods.TOKEN_ActivePlayers().call().then(busd2 => {
			document.getElementById("activeplayersbusd").textContent = "Sold Tickets =  " + busd2;
		});
}, 10000);

const busd3 = new web3node.eth.Contract(BUSDLOTTOABI, BUSDLOTTOADDRESS)
	.methods.TOKEN_maxplayers_perlotto().call().then(busd3 => {
		document.getElementById("maxplayersbusd").textContent = "Tickets per lotto =  " + busd3;
	});



const busd4 = new web3node.eth.Contract(BUSDLOTTOABI, BUSDLOTTOADDRESS)
	.methods.TOKENCost().call().then(busd4 => {
		var b = busd4 / 1e18;
		var bstring = b.toString();
		var int = parseFloat(bstring).toFixed(0);
		document.getElementById("ticketcostbusd").textContent = "Price = " + int + " BUSD";
	});

setInterval(function () {
	const busd4 = new web3node.eth.Contract(BUSDLOTTOABI, BUSDLOTTOADDRESS)
		.methods.TOKENCost().call().then(busd4 => {
			var b = busd4 / 1e18;
			var bstring = b.toString();
			var int = parseFloat(bstring).toFixed(0);
			document.getElementById("ticketcostbusd").textContent = "Price = " + int + " BUSD";
		});
}, 10000);

const busd5 = new web3node.eth.Contract(BUSDLOTTOABI, BUSDLOTTOADDRESS)
	.methods.get_TOKEN_Balance().call().then(busd5 => {
		var bbbt1 = busd5 / 1e18;
		var stt = bbbt1.toString();
		var number = stt;
		var nodecimals = number | 0;
		document.getElementById("busdpot").textContent = "POT: " + nodecimals + " BUSD";
	});

setInterval(function () {
	const busd5 = new web3node.eth.Contract(BUSDLOTTOABI, BUSDLOTTOADDRESS)
		.methods.get_TOKEN_Balance().call().then(busd5 => {
			var bbbt1 = busd5 / 1e18;
			var stt = bbbt1.toString();
			var number = stt;
			var nodecimals = number | 0;
			document.getElementById("busdpot").textContent = "POT: " + nodecimals + " BUSD";
		});
}, 10000);

//-------------------------------------------------------------------------------------------

//------------- LUCKY VALUES ---------------------------


userpoints = async () => {
    const contract = new web3node.eth.Contract(LUCKYABI, LUCKADDRESS);
    const points = await contract.methods.get_User_Points(currentAddr).call().then(points => {
        document.getElementById("luckypoints").textContent = points + "p = User Points "; 
    })
}

busdbalance = async () => {
    const contract = new web3node.eth.Contract(LUCKYABI, LUCKADDRESS);
    const busdbalance = await contract.methods.get_BUSD_Balance().call().then(busdbalance => {
        var balance = busdbalance/1e18
        var bstring = balance.toString();
        var result = parseFloat(bstring).toFixed(2);
        document.getElementById("busdbalance").textContent = result + " BUSD"; 
    })
}

blfibalance = async () => {
    const contract = new web3node.eth.Contract(LUCKYABI, LUCKADDRESS);
    const blfibalance = await contract.methods.get_BLFI_Balance().call().then(blfibalance => {
        var balance = blfibalance/1e18
        var bstring = balance.toString();
        var result = parseFloat(bstring).toFixed(2);
        document.getElementById("blfibalance").textContent = result + " BLFI"; 
    })
}

bnbbalance = async () => {
    const contract = new web3node.eth.Contract(LUCKYABI, LUCKADDRESS);
    const bnbbalance = await contract.methods.get_BNB_Balance().call().then(bnbbalance => {
        var balance = bnbbalance/1e18
        var bstring = balance.toString();
        var result = parseFloat(bstring).toFixed(2);
        document.getElementById("bnbbalance").textContent = result + " BNB"; 
    })
}

reducepoints = async () => {
    const contract = new web3node.eth.Contract(LUCKYABI, LUCKADDRESS);
    const jackpotpoints = await contract.methods.reducepoints().call().then(jackpotpoints => {        
        document.getElementById("jackpotunlocked").textContent = jackpotpoints + "p = Jackpot Access"; 
    })
}

royalitiepoints = async () => {
    const contract = new web3node.eth.Contract(LUCKYABI, LUCKADDRESS);
    const blfipoints = await contract.methods.royalitiepoints().call().then(blfipoints => {        
        document.getElementById("claimunlocked").textContent = blfipoints + "p = Claim Access"; 
    })
}

ticketcost = async () => {
    const contract = new web3node.eth.Contract(LUCKYABI, LUCKADDRESS);
    const bnbbalance = await contract.methods.TOKENCost().call().then(bnbbalance => {
        var balance = bnbbalance/1e18
        var bstring = balance.toString();
        var result = parseFloat(bstring).toFixed(2);
        document.getElementById("luckyticket").textContent = result + " BUSD"; 
    })
}


//---------- LUCKY FUNCTIONS ----------------

getroyalities = async () => {
    const contract = new web3.eth.Contract(LUCKYABI, LUCKADDRESS);
    const claimed = await contract.methods.get_Royalities().send({ from: currentAddr })	
	alert("SUCCESS !! \n\n BLOCKIFY CLAIMED !!")
}

getluckyclaimer = async () => {
    //console.log('LuckyClaimer Button');
    const contract = new web3node.eth.Contract(LUCKYABI, LUCKADDRESS);

    const pointschecker = await contract.methods.get_User_Points(currentAddr).call().then(pointschecker =>{
		userpointsx = pointschecker;
		console.log("USER POINTS = " + userpointsx);
	})
    const blfipointschecker = await contract.methods.royalitiepoints().call().then(blfipointschecker => {
		minimumpoints = blfipointschecker;
		console.log("MINIMUM POINTS = " + minimumpoints);
	})

    const blfibalance = await contract.methods.get_BLFI_Balance().call()
        var balance = blfibalance/1e18
        var bstring = balance.toString();
        var result = parseFloat(bstring).toFixed(2);
        var userresult = result/2;
        
    
    //console.log(pointschecker);
    //console.log(blfipointschecker)

	const userpointsvalue = userpointsx;
	const minimumpointsvalue  = minimumpoints;

    if (userpointsvalue>50) {

		alert('CURRENT BALANCE= ' + result + " BLOCKIFY (BLFI) \n\n YOU WILL RECEIVE= " + userresult + " BLFI (50%) \n\n BLFI TO BURN= " + userresult + " BLFI (50%) \n\n" + minimumpointsvalue + " Points will be deducted from balance! \n\n To accept confirm transaction!")
		getroyalities();

	}else {
		alert(" NOT ENOUGH POINTS TO CLAIM BLFI!\n\n YOUR POINTS= " + userpointsvalue + "\n POINTS REQUIRED= " + minimumpointsvalue + "\n\n TO USE CLAIM FUNCTION!")
		
	}

}

checktimer = async () =>{
    contract = new web3.eth.Contract(LUCKYABI, LUCKADDRESS);    
    const time = await contract.methods.gettime(currentAddr).call()
    //console.log(time);

    if (time== true){
        getluckybuyticket();
    }else{
        alert("🚨COOL DOWN TIME!!🚨 \n\n\ WAIT 3 MINUTES TO PLAY AGAIN")
    }
    
}

getluckyaprovebusd = async () => {
	//console.log('Get busd spend approval');
	
	contract = new web3.eth.Contract(busdabi, busdaddress);
	 alert('🚨 APROVING BUSD TO PLAY 🚨 \n \n \n YOUR BUSD TOKENS WILL NOT BE SPEND ON THIS TRANSACTION \n\n\n APPROVE REQUIRED TO PLAY!');
	
	const receipt = await contract.methods.approve(LUCKADDRESS, "100000000000000000000").send({ from: currentAddr })
	//console.log(receipt.events);	

    //check time delay first
	getluckybuyticket();
}

getluckybuyticket = async () => {
	//console.log('BUSD Buy Ticket');
	
	contract = new web3.eth.Contract(LUCKYABI, LUCKADDRESS);
	const cost = await contract.methods.TOKENCost().call().then(cost => {
		costwei = cost;
		//console.log(cost);
		
		//console.log(eprice);

		

	});

	//check BUSD BALANCE vs TICKET COST HERE
	busdchecker = new web3.eth.Contract(busdabi, busdaddress);
	const busdbalance = await busdchecker.methods.balanceOf(currentAddr).call().then(busdbalance =>{
		balancewei = busdbalance;
		console.log("BUSD USER WEI BALANCE = " + balancewei);
		var ebalance = busdbalance/1e18;
		console.log("USER BALANCE BUSD READABLE = " + ebalance);		

	});

	const ticketprice = costwei;
	const userbalwei = balancewei;

	const ti = ticketprice / 1e18;
	const us = userbalwei / 1e18;
	
	 

	if (us>=ti){
		console.log("ALLOWED TO PLAY!")
		alert('TICKET PRICE : \n\n ' + ti + ' BUSD TOKENS \n\n To Play confirm Transaction, Tokens will be spent!')
		playaction();
	}else{
		alert("NOT ENOUGH BUSD TO PLAY!")
	}

}


playaction = async () => {

	const pbusd = await contract.methods.PLAY_TOKEN_LOTTO().send({ from: currentAddr });
	
    
    const result = await pbusd.events.SELECTOR.returnValues['selector'];

	console.log(result);

	const pointschecker = await contract.methods.get_User_Points(currentAddr).call()
    const blfipointschecker = await contract.methods.royalitiepoints().call()

    if (result == 1){

        const prize = await pbusd.events.WINNER.returnValues['Prize'];
        const points = await pbusd.events.WINNER.returnValues['Points'];
        var baltostring = prize/1e18
        var bstring = baltostring.toString();
        var prizeresult = parseFloat(bstring).toFixed(4);

        alert("!! WINNER !!\n\n\ YOU WIN = " + prizeresult + " BUSD\n\n POINTS EARNED = " + points);

    }if (result == 4 && pointschecker>=blfipointschecker){
        const prize = await pbusd.events.JACKPOT_WINNER.returnValues['Prize'];
        const points = await pbusd.events.JACKPOT_WINNER.returnValues['Points'];

        var baltostring = prize/1e18
        var bstring = baltostring.toString();
        var prizeresult = parseFloat(bstring).toFixed(4);
        
        alert("!! BIG WINNER !!\n\n\ YOU WIN = " + prizeresult + " BNB\n\n POINTS EARNED = " + points);

    }else{
        
        const points = await pbusd.events.LOSER.returnValues['Points'];
        alert("NOT EVERYTHING IS LOST! \n\n  YOU EARNED = " + points + " POINTS" );
    }
}

getluckyplay = async () => {
	//console.log('CHECKING ALLOWANCE, BUSD TOKEN');
	
	contract = new web3.eth.Contract(busdabi, busdaddress);

	const checker = await contract.methods.allowance(currentAddr, LUCKADDRESS).call().then(checker => {
		checkerstatus = checker;
		//console.log(checkerstatus);
	});

	contract = new web3.eth.Contract(LUCKYABI, LUCKADDRESS);
	const cost = await contract.methods.TOKENCost().call().then(cost => {
		costwei = cost;
		 // console.log(cost);
		var eprice = cost / 1e18;
		 //console.log(eprice);
		

	});

	//console.log("ALLOWANCE = 'CHECKER STATUS' " + currentAddr + " " + checkerstatus);
	//console.log(" BUSD PRICE " + costwei);

	const ticketprice = costwei;
	const userallowance = checkerstatus;

	const ti = ticketprice / 1e18;
	const us = userallowance / 1e18;
	//console.log(ti, us)

	//console.log("TICKET PRICE = " + ticketprice + "\nUSER ALLOWANCE = " + userallowance)

	if (us < ti) {

		getluckyaprovebusd();

	} else {
        checktimer();		
	}


}


//----------- INSTANT DRAW  ---------------
if (document.querySelector('#luckyclaimer') != null) {
	document.querySelector('#luckyclaimer').onclick = getluckyclaimer;
}
if (document.querySelector('#aproveluckybusd') != null) {
	document.querySelector('#aproveluckybusd').onclick = getluckyplay;
}
