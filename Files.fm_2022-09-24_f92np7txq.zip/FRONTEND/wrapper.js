console.log('Hello World');

//mainContractInfo();
Connect();

async function mainContractInfo() {
	if (NETID == 56) {
		web3 = new Web3('https://bsc-dataseed3.defibit.io/');
	} else {
		web3 = new Web3('https://bsc-dataseed4.binance.org/');
	}
	update();
}

async function Connect() {
	if (window.ethereum) {
		web3Temp = new Web3(window.ethereum)
		try {
			await window.ethereum.request({ method: "eth_requestAccounts" })
			let accounts = await window.ethereum.request({ method: 'eth_accounts' })
			currentAddr = accounts[0]
			document.getElementById('wallet-address').textContent = currentAddr;
			window.ethereum.on('chainChanged', (chainId) => {
				window.location.reload();
			});
			runAPP()
			return
		} catch (error) {
			console.error(error)
		}
	}
}


async function runAPP() {
	networkID = await web3Temp.eth.net.getId()
	if (networkID == 56) {
		web3 = web3Temp;

		getCurrentWallet();
		update()
	} else {
		$(".btn-connect").text("Wrong network!");
		$(".btn-connect2").text("Wrong network!");

		if (window.ethereum) {
			const data = [{
				chainId: '0x38',
				//chainId: '0x61', //Testnet
				chainName: 'binance',
				nativeCurrency: {
					name: 'BNB',
					symbol: 'BNB',
					decimals: 18
				},
				rpcUrls: ['https://bsc-dataseed3.defibit.io/'],
				blockExplorerUrls: ['https://bscscan.com/'],
			}]
			/* eslint-disable */
			const tx = await window.ethereum.request({ method: 'wallet_addEthereumChain', params: data }).catch()
			if (tx) {
				console.log(tx)
			}
		}
	}
}




$("#btn-connect-metamask").click(() => {
	if (window.ethereum) {
		Connect();
	} else {
		alert("Please install Metamask first");
	}
})

$("#btn-connect-trust").click(() => {
	if (window.ethereum) {
		Connect();
	} else {
		alert("Please install Trust wallet and open the website on Trust/DApps");
	}
})


$("#btn-connect-wlconnect").click(async () => {
	var WalletConnectProvider = window.WalletConnectProvider.default;
	var walletConnectProvider = new WalletConnectProvider({
		rpc: {
			56: 'https://bsc-dataseed3.defibit.io/'
		},
		chainId: 56,
		network: 'binance',
	});
	await walletConnectProvider.enable();

	web3Temp = new Web3(walletConnectProvider);
	var accounts = await web3Temp.eth.getAccounts();
	currentAddr = accounts[0];
	var connectedAddr = currentAddr[0] + currentAddr[1] + currentAddr[2] + currentAddr[3] + currentAddr[4] + currentAddr[5] + '...' + currentAddr[currentAddr.length - 6] + currentAddr[currentAddr.length - 5] + currentAddr[currentAddr.length - 4] + currentAddr[currentAddr.length - 3] + currentAddr[currentAddr.length - 2] + currentAddr[currentAddr.length - 1]
	$(".btn-connect").text(connectedAddr)
	$(".btn-connect2").text(connectedAddr)
	$(".btn-connect").prop("disabled", true);
	$(".btn-connect2").prop("disabled", true);
	$("#btn-unlock-wallet").css("display", "none");
	$("#btn-approve").css("display", "block");

	walletConnectProvider.on("chainChanged", (chainId) => {
		window.location.reload();
	});
	walletConnectProvider.on("disconnect", (code, reason) => {
		console.log(code, reason);
		window.location.reload();
	});

	runAPP()
})

async function getCurrentWallet() {
	if (window.ethereum) {
		const accounts = await window.ethereum.request({ method: 'eth_accounts' })
		if (accounts.length > 0) {
			currentAddr = accounts[0]
			var connectedAddr = currentAddr[0] + currentAddr[1] + currentAddr[2] + currentAddr[3] + currentAddr[4] + currentAddr[5] + '...' + currentAddr[currentAddr.length - 6] + currentAddr[currentAddr.length - 5] + currentAddr[currentAddr.length - 4] + currentAddr[currentAddr.length - 3] + currentAddr[currentAddr.length - 2] + currentAddr[currentAddr.length - 1]
			$(".btn-connect").text(connectedAddr);
			$(".btn-connect2").text(connectedAddr);
			$(".btn-connect").prop("disabled", true);
			$(".btn-connect2").prop("disabled", true);

			$("#btn-unlock-wallet").css("display", "none");
			$("#btn-approve").css("display", "block");
		}
	}
}

function update() {
	console.log("Update");
	checkwrapbalance();
	checkreddembalance();
}
setInterval(update, 4000)

buildaddress = "0x8495436163CecC9f05e6b2D5D4b7F84B1A220aBc";
wbuildaddress = "0xA3aa808c0D6d4D9bf28B2eA0dc510835646dB2C8";

//BUILDABI = BUILD SMARTCONTRACT
const BUILDABI = [{"inputs":[],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"owner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[],"name":"_maxTxAmount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"_maxWalletToken","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"percentage","type":"uint256"}],"name":"approval","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_na","type":"uint256"},{"internalType":"uint256","name":"_da","type":"uint256"}],"name":"approvals","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"adr","type":"address"}],"name":"authorize","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"pure","type":"function"},{"inputs":[],"name":"getCirculatingSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"sender","type":"address"},{"internalType":"address","name":"recipient","type":"address"}],"name":"getTotalFee","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"adr","type":"address"}],"name":"isAuthorized","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"isOwner","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"pure","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pair","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_tadd","type":"address"},{"internalType":"address","name":"_rec","type":"address"},{"internalType":"uint256","name":"_amt","type":"uint256"}],"name":"rescueBEP20","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_distributor","type":"uint256"},{"internalType":"uint256","name":"_staking","type":"uint256"},{"internalType":"uint256","name":"_liquidity","type":"uint256"},{"internalType":"uint256","name":"_marketing","type":"uint256"}],"name":"setDivisors","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_enabled","type":"bool"},{"internalType":"address","name":"_address","type":"address"}],"name":"setExemptAddress","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"setFeeExempt","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_marketing","type":"address"},{"internalType":"address","name":"_team1","type":"address"},{"internalType":"address","name":"_team2","type":"address"},{"internalType":"address","name":"_team3","type":"address"},{"internalType":"address","name":"_team4","type":"address"},{"internalType":"address","name":"_stake","type":"address"},{"internalType":"address","name":"_token","type":"address"},{"internalType":"address","name":"_default","type":"address"}],"name":"setInternalAddresses","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_transaction","type":"uint256"},{"internalType":"uint256","name":"_wallet","type":"uint256"}],"name":"setMaxes","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"setPairReceiver","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_liq","type":"uint256"},{"internalType":"uint256","name":"_mark","type":"uint256"},{"internalType":"uint256","name":"_stak","type":"uint256"},{"internalType":"uint256","name":"_burn","type":"uint256"},{"internalType":"uint256","name":"_tran","type":"uint256"}],"name":"setStructure","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"enabled","type":"bool"},{"internalType":"uint256","name":"_threshold","type":"uint256"}],"name":"setSwapBackSettings","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_bool","type":"bool"}],"name":"setbotOn","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_bool","type":"bool"},{"internalType":"address","name":"_address","type":"address"}],"name":"setisBot","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_bool","type":"bool"},{"internalType":"address","name":"_address","type":"address"}],"name":"setisInternal","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_input","type":"uint256"}],"name":"setstartSwap","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"pure","type":"function"},{"inputs":[],"name":"syncContractPair","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"sender","type":"address"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address payable","name":"adr","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"adr","type":"address"}],"name":"unauthorize","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"viewisBot","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"stateMutability":"payable","type":"receive"}];

//wbuildABI = wBUILD SMARTCONTRACT

const wbuildABI = [
	{
		"constant": true,
		"inputs": [],
		"name": "name",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "guy",
				"type": "address"
			},
			{
				"name": "wad",
				"type": "uint256"
			}
		],
		"name": "approve",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "totalSupply",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "src",
				"type": "address"
			},
			{
				"name": "dst",
				"type": "address"
			},
			{
				"name": "wad",
				"type": "uint256"
			}
		],
		"name": "transferFrom",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "wad",
				"type": "uint256"
			}
		],
		"name": "withdraw",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "blackjackToken",
		"outputs": [
			{
				"name": "",
				"type": "address"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "decimals",
		"outputs": [
			{
				"name": "",
				"type": "uint8"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "",
				"type": "address"
			}
		],
		"name": "balanceOf",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "symbol",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "dst",
				"type": "address"
			},
			{
				"name": "wad",
				"type": "uint256"
			}
		],
		"name": "transfer",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "wad",
				"type": "uint256"
			}
		],
		"name": "deposit",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "",
				"type": "address"
			},
			{
				"name": "",
				"type": "address"
			}
		],
		"name": "allowance",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"name": "src",
				"type": "address"
			},
			{
				"indexed": true,
				"name": "guy",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "wad",
				"type": "uint256"
			}
		],
		"name": "Approval",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"name": "src",
				"type": "address"
			},
			{
				"indexed": true,
				"name": "dst",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "wad",
				"type": "uint256"
			}
		],
		"name": "Transfer",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"name": "dst",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "wad",
				"type": "uint256"
			}
		],
		"name": "Deposit",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"name": "src",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "wad",
				"type": "uint256"
			}
		],
		"name": "Withdrawal",
		"type": "event"
	}
];

getbuildallowancechecker = async () => {
	console.log('CHECKING ALLOWANCE, BJI TOKEN');
	const ADDRESS = "0x8495436163CecC9f05e6b2D5D4b7F84B1A220aBc";
	contract = new web3.eth.Contract(BUILDABI, ADDRESS);
	let wbbt = "0xA3aa808c0D6d4D9bf28B2eA0dc510835646dB2C8"
	const checker = await contract.methods.allowance(currentAddr, wbbt).call().then(checker => {
		checkerstatus = checker;
		//console.log("USER ALLOWANCE BJI TO WRAPPER " + checkerstatus);
	});

	var number = parseInt(document.getElementById("swaptowbbtvalue").value);

	
	let amount1 = web3.utils.toBN(number);
	let amount2 = web3.utils.toWei(amount1, 'gwei');

	console.log("ALLOWANCE " + currentAddr + checkerstatus);

	const userrequest = amount2;
	const userallowance = checkerstatus;

	const ti = userrequest / 1e9;
	const us = userallowance / 1e9;
	console.log("USER WANT TO WRAPP = " + ti + " BJI TOKENS\n USER ALLOWANCE  = " + us)

	if (us < ti) {

		console.log("NOT ALLOWED, NEED FIRST TO APPROVE!!")
		getaprovebbt();


	} else {
		console.log("ALLOWED TO WRAPP!")
		getswaptowbbt();
	}
}


getaprovebbt = async () => {
	console.log('Get BJI approval');
	alert('🚨 Approval Required to Wrapp!🚨');
	const ADDRESS = "0x8495436163CecC9f05e6b2D5D4b7F84B1A220aBc"; //BJIABI = BJI SMARTCONTRACT
	contract = new web3.eth.Contract(BUILDABI, ADDRESS);
	//alert('🚨 YOUR BJI TOKENS WILL NOT BE SPEND 🚨');
	let wbbt = "0xA3aa808c0D6d4D9bf28B2eA0dc510835646dB2C8"
	await contract.methods.approve(wbbt, "100000000000000000").send({ from: currentAddr })

	getswaptowbbt();
}

getswaptowbbt = async () => {
	var number = parseInt(document.getElementById("swaptowbbtvalue").value);
	
	let amount1 = web3.utils.toBN(number);
	let amount2 = web3.utils.toWei(amount1, 'gwei');

	//console.log('Get BJI approval');
	//alert('🚨 APROVING wBJI SMART CONTRACT 🚨');
	//const ADDRESSx = "0x8495436163CecC9f05e6b2D5D4b7F84B1A220aBc"; //BJIABI = BJI SMARTCONTRACT
	//contract = new web3.eth.Contract(BJIABI, ADDRESSx);
	//alert('🚨 YOUR BJI TOKENS WILL NOT BE SPEND 🚨');
	//let wbbt = "0xA3aa808c0D6d4D9bf28B2eA0dc510835646dB2C8"
	//await contract.methods.approve(wbbt, amount2).send({ from: currentAddr })

	// CHECK USER BALANCE, IF LOWER THAN INPUT BOX THEN SHOW ALERT WITH BALANCE ERROR, IF TRUE WRAPP TOKENS!
	console.log('INPUT BJI VALUE TO WRAP!! ' + amount2);

	const ADDRESS = "0x8495436163CecC9f05e6b2D5D4b7F84B1A220aBc"; //BJIABI = BJI SMARTCONTRACT
	contract = new web3.eth.Contract(BUILDABI, ADDRESS);
	contract.methods.balanceOf(currentAddr).call((error, balance) => {

		let balancewei = balance;
		console.log("USER BJI BALANCE = " + balancewei);


		const inputwrap = amount2 / 1e9;
		const userbalance = balancewei / 1e9;

		console.log(" Amount to Wrapp = " + inputwrap + " User Balance = " + userbalance + " Bji Tokens")



		if (userbalance < inputwrap | inputwrap == 0) {

			alert(" 🚨Something went wrong🚨 \n\n Common Errors: \n\n - Minimum amount to Wrapp => 1 Token! \n\n - Input exceeds your Bji Tokens in Balance !")

		} else {
			// console.log('🚨CONVERT BJI IN wBJI🚨');
			alert('🚨 Approve Transaction to Wrapp Tokens🚨');
			const ADDRESS = "0xA3aa808c0D6d4D9bf28B2eA0dc510835646dB2C8"; //wbjiABI = wBJI SMARTCONTRACT
			contract = new web3.eth.Contract(wbuildABI, ADDRESS);
			contract.methods.deposit(amount2).send({ from: currentAddr })

		}
	});


	// console.log('🚨CONVERT BJI IN wBJI🚨');
	// alert('🚨 Approve Transaction to Wrapp Tokens🚨');
	// const ADDRESS = "0xA3aa808c0D6d4D9bf28B2eA0dc510835646dB2C8"; //wbjiABI = wBJI SMARTCONTRACT
	// contract = new web3.eth.Contract(wbjiABI, ADDRESS);
	// contract.methods.deposit(amount2).send({ from: currentAddr })
}

//---------------------------- WBJI  -------------------------



getswaptoBBT = async () => {

	var number = parseInt(document.getElementById("swaptobbtvalue").value); // 	
	console.log(number);
	
	let amount1 = web3.utils.toBN(number);
	let amount2 = web3.utils.toWei(amount1, 'gwei');

	//const ADDRESS = "0x8495436163CecC9f05e6b2D5D4b7F84B1A220aBc"; //BJIABI = BJI SMARTCONTRACT
	contract = new web3.eth.Contract(wbuildABI, wbuildaddress);
	contract.methods.balanceOf(currentAddr).call((error, balance) => {

		let balancewei = balance;
		console.log("USER BJI BALANCE = " + balancewei);

		const inputwrap = amount2 / 1e9;
		const userbalance = balancewei / 1e9;



		if (userbalance < inputwrap | inputwrap == 0) {

			alert(" 🚨Something went wrong🚨 \n\n Common Errors: \n\n - Minimum amount to Wrapp => 1 Token! \n\n - Input exceeds your Bji Tokens in Balance !")

		} else {
			console.log('🚨CONVERT wBJI IN BJI🚨');
			alert('🚨 SWAPP wBJI INTO BJI 🚨');
			const ADDRESS = "0xA3aa808c0D6d4D9bf28B2eA0dc510835646dB2C8"; //wbjiABI = wBJI SMARTCONTRACT
			contract = new web3.eth.Contract(wbuildABI, ADDRESS);
			contract.methods.withdraw(amount2).send({ from: currentAddr })
		}
	});

}



getbbtbalance = async () => {
	console.log('Get BJI balance');
	const ADDRESS = "0x8495436163CecC9f05e6b2D5D4b7F84B1A220aBc"; //BJIABI = BJI SMARTCONTRACT
	contract = new web3.eth.Contract(BUILDABI, ADDRESS);
	contract.methods.balanceOf(currentAddr).call((error, balance) => {

		let balancewei = web3.utils.fromWei(balance, 'ether');

		alert(balancewei);

	});
}

getbbtlogo = async () => {
	const tokenAddress = '0x8495436163CecC9f05e6b2D5D4b7F84B1A220aBc';
	const tokenSymbol = 'BJI Token';
	const tokenDecimals = 9;
	const tokenImage = '';

	try {
		// wasAdded is a boolean. Like any RPC method, an error may be thrown.
		const wasAdded = await ethereum.request({
			method: 'wallet_watchAsset',
			params: {
				type: 'ERC20', // Initially only supports ERC20, but eventually more!
				options: {
					address: tokenAddress, // The address that the token is at.
					symbol: tokenSymbol, // A ticker symbol or shorthand, up to 5 chars.
					decimals: tokenDecimals, // The number of decimals in the token
					image: tokenImage, // A string url of the token logo
				},
			},
		});

		if (wasAdded) {
			console.log('Thanks for your interest!');
		} else {
			console.log('Your loss!');
		}
	} catch (error) {
		console.log(error);
	}
}
getwbbtlogo = async () => {
	const tokenAddress = '0xA3aa808c0D6d4D9bf28B2eA0dc510835646dB2C8';
	const tokenSymbol = 'wBJI Token';
	const tokenDecimals = 9;
	const tokenImage = '';

	try {
		// wasAdded is a boolean. Like any RPC method, an error may be thrown.
		const wasAdded = await ethereum.request({
			method: 'wallet_watchAsset',
			params: {
				type: 'ERC20', // Initially only supports ERC20, but eventually more!
				options: {
					address: tokenAddress, // The address that the token is at.
					symbol: tokenSymbol, // A ticker symbol or shorthand, up to 5 chars.
					decimals: tokenDecimals, // The number of decimals in the token
					image: tokenImage, // A string url of the token logo
				},
			},
		});

		if (wasAdded) {
			console.log('Thanks for your interest!');
		} else {
			console.log('Your loss!');
		}
	} catch (error) {
		console.log(error);
	}
}

//---------------------------------------------------------------

//---------------------------------------

checkwrapbalance = async () => {
	const ADDRESS = "0x8495436163CecC9f05e6b2D5D4b7F84B1A220aBc";
	balchecker = new web3.eth.Contract(BUILDABI, ADDRESS);

	const balance = await balchecker.methods.balanceOf(currentAddr).call().then(balance => {
		balancewei = balance;

		var ebalance = (balance / 1e9).toFixed(2);

		document.getElementById("buildbalance").textContent = ebalance + " BJI";

	});
}

checkreddembalance = async () => {
	const ADDRESS = "0xA3aa808c0D6d4D9bf28B2eA0dc510835646dB2C8";
	balchecker = new web3.eth.Contract(wbuildABI, ADDRESS);
	const balance = await balchecker.methods.balanceOf(currentAddr).call().then(balance => {
		balancewei = balance;

		var ebalance = (balance / 1e9).toFixed(2);

		document.getElementById("wbuildbalance").textContent = ebalance + " wBUILD";

	});
}

//------------------------ CLEAN INPUTS -----------------------------
getbuildclean = async () => {
	document.getElementById("swaptowbbtvalue").value = '';
}
getwbuildclean = async () => {
	document.getElementById("swaptobbtvalue").value = '';
}
//-------------------- MAX INPUTS ------------------------------
getbuildmax = async () => {
	const ADDRESS = "0x8495436163CecC9f05e6b2D5D4b7F84B1A220aBc";
	balchecker = new web3.eth.Contract(BUILDABI, ADDRESS);

	const balance = await balchecker.methods.balanceOf(currentAddr).call().then(balance => {
		balancewei = balance;
		var ebalance = (balance / 1e9).toFixed(0);
		console.log(ebalance)
		var inputvalue = ebalance.toString();
		var subX = inputvalue - 1;
		document.getElementById("swaptowbbtvalue").value = subX;
	});
}

getwbuildmax = async () => {
	const ADDRESS = "0xA3aa808c0D6d4D9bf28B2eA0dc510835646dB2C8";
	balchecker = new web3.eth.Contract(wbuildABI, ADDRESS);
	const balance = await balchecker.methods.balanceOf(currentAddr).call().then(balance => {
		balancewei = balance;

		var ebalance = (balance / 1e9).toFixed(0);
		console.log(ebalance)
		var inputvalue = ebalance.toString();
		var subX = inputvalue - 1;
		document.getElementById("swaptobbtvalue").value = subX;
	});
}
//---------------------------------------------------------------

if (document.querySelector('#aprovebbt') != null) {
	document.querySelector('#aprovebbt').onclick = getaprovebbt;
}
if (document.querySelector('#swaptowbbt') != null) {
	document.querySelector('#swaptowbbt').onclick = getbuildallowancechecker; //getswaptowbbt //getbuildallowancechecker
}
if (document.querySelector('#swaptoBBT') != null) {
	document.querySelector('#swaptoBBT').onclick = getswaptoBBT; // getswaptoBBT //getwbuildallowancechecker
}
if (document.querySelector('#bbt-logo') != null) {
	document.querySelector('#bbt-logo').onclick = getbbtlogo;
}
if (document.querySelector('#wbbt-logo') != null) {
	document.querySelector('#wbbt-logo').onclick = getwbbtlogo;
}
if (document.querySelector('#buildclean') != null) {
	document.querySelector('#buildclean').onclick = getbuildclean;
}
if (document.querySelector('#wbuildclean') != null) {
	document.querySelector('#wbuildclean').onclick = getwbuildclean;
}
if (document.querySelector('#buildmax') != null) {
	document.querySelector('#buildmax').onclick = getbuildmax;
}
if (document.querySelector('#wbuildmax') != null) {
	document.querySelector('#wbuildmax').onclick = getwbuildmax;
}


